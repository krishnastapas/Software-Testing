package security;

/**
 * Author: Koushik Sen <ksen@cs.uiuc.edu>
 */
public class Message {
    public static Message m;
}
