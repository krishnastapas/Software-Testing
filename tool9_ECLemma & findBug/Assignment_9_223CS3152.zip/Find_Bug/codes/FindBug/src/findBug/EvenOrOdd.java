package findBug;

public class EvenOrOdd {
	 public static String checkEvenOrOdd(int number) {
	        return (number % 2 == 0) ? "Even" : "Odd";
	    }
}
