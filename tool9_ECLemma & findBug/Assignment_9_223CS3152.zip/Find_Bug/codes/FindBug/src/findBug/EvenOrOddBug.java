package findBug;

public class EvenOrOddBug {
	 public static String checkEvenOrOdd(int number) {
	        return (number % 2 == 0) ? "Even" : "Odd";
	    }
}
